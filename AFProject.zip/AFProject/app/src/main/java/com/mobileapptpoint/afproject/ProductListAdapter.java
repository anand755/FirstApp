package com.mobileapptpoint.afproject;

import android.content.Context;
import android.content.Intent;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

/**
 * Created by ban82779 on 22/01/18.
 */

public class ProductListAdapter extends BaseAdapter {


    private Context context;
    private Product[] products;


    public ProductListAdapter(Context context, Product[] products) {
        this.context = context;
        this.products = products;
    }


    @Override
    public int getCount() {
        return products.length;
    }

    @Override
    public Product getItem(int position) {

        return products[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;
        Button button = null;

        final Product product = getItem(position);

        if (convertView == null) {
            final LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            convertView = inflater.inflate(R.layout.item_product_layout, null);
            holder = new ViewHolder();
            holder.backgroundImage = (ImageView) convertView.findViewById(R.id.backgroundImage);
            holder.topDesccription = (TextView) convertView.findViewById(R.id.topDesccription);
            holder.title = (TextView) convertView.findViewById(R.id.title);
            holder.promoMessage = (TextView) convertView.findViewById(R.id.promoMessage);

            holder.bottomDescription = (TextView) convertView.findViewById(R.id.bottomDescription);


            holder.llMain = (LinearLayout) convertView.findViewById(R.id.ll_main);

            if (product.getContent() != null) {
                for (int i = 0; i < product.getContent().size(); i++) {
                    button = new Button(context);
                    button.setText(product.getContent().get(i).getTitle());
                    button.setTextSize(15);
                    button.setBackgroundResource(R.drawable.button_background);

                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                    params.setMargins(70,10,70,10);

                    final String url = product.getContent().get(i).getTarget();
                    button.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(context, WebActivity.class);
                            intent.putExtra("url", url);
                            context.startActivity(intent);
                        }
                    });
                    holder.llMain.addView(button,params);
                }
            }

            if (product.getBottomDescription() != null) {
                holder.bottomDescription.setText(Html.fromHtml(product.getBottomDescription()));

                holder.bottomDescription.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int start = product.getBottomDescription().indexOf("http");
                        int end = product.getBottomDescription().indexOf("html");

                        String lnkS = product.getBottomDescription().substring(start, end + 4);
                        Intent intent = new Intent(context, WebActivity.class);
                        intent.putExtra("url", lnkS);
                        context.startActivity(intent);
                    }
                });

            }
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Glide.with(holder.backgroundImage.getContext()).load(product.getBackgroundImage()).into(holder.backgroundImage);

        holder.topDesccription.setText(product.getTopDescription());
        holder.title.setText(product.getTitle());
        holder.promoMessage.setText(product.getPromoMessage());

        if (product.getBottomDescription() != null) {
            holder.bottomDescription.setText(Html.fromHtml(product.getBottomDescription()));

            holder.bottomDescription.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int start = product.getBottomDescription().indexOf("http");
                    int end = product.getBottomDescription().indexOf("html");

                    String lnkS = product.getBottomDescription().substring(start, end + 4);
                    Intent intent = new Intent(context, WebActivity.class);
                    intent.putExtra("url", lnkS);
                    context.startActivity(intent);
                }
            });
        }

        ////////////////////

        if (holder.topDesccription.getText().equals("")){
            holder.topDesccription.setVisibility(View.GONE);
        }else {
            holder.topDesccription.setVisibility(View.VISIBLE);
        }

        if (holder.title.getText().equals("")){
            holder.title.setVisibility(View.GONE);
        }else {
            holder.title.setVisibility(View.VISIBLE);
        }

        if (holder.promoMessage.getText().equals("")){
            holder.promoMessage.setVisibility(View.GONE);
        }else {
            holder.promoMessage.setVisibility(View.VISIBLE);
        }

        if (holder.bottomDescription.getText().equals("")){
            holder.bottomDescription.setVisibility(View.GONE);
        }else {
            holder.bottomDescription.setVisibility(View.VISIBLE);
        }

        ///////////////////////





        convertView.setTag(holder);
        return convertView;
    }

    static class ViewHolder {
        ImageView backgroundImage;
        TextView topDesccription;
        TextView title;
        TextView promoMessage;
        TextView bottomDescription;
        LinearLayout llMain;
    }

}
